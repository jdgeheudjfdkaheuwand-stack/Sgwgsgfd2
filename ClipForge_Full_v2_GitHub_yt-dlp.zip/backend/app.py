import os, re, uuid, shutil, asyncio, subprocess
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel
import yt_dlp

app=FastAPI(title="ClipForge Downloader")
BASE=Path(os.getenv("DOWNLOAD_DIR","/tmp/clipforge"))
BASE.mkdir(parents=True,exist_ok=True)
MAX_GB=float(os.getenv("MAX_FILE_GB","1024"))
API_KEY=os.getenv("DOWNLOADER_API_KEY","")

class Job(BaseModel):
    url:str
    type:str="video"
    quality:int=8

def auth(x_api_key):
    if API_KEY and x_api_key!=API_KEY:
        raise HTTPException(401,"Invalid API key")

def quality_fmt(q:int):
    q=max(0,min(10,q))
    heights=[360,480,540,720,1080,1440,2160,2160,2160,4320,4320]
    h=heights[q]
    return f"bv*[height<={h}]+ba/b[height<={h}]/b"

@app.get("/health")
def health(): return {"ok":True,"service":"ClipForge"}

@app.get("/info")
def info(url:str):
    try:
        with yt_dlp.YoutubeDL({"quiet":True,"skip_download":True,"noplaylist":True}) as y:
            d=y.extract_info(url,download=False)
        return {"title":d.get("title") or "Медиа","thumbnail":d.get("thumbnail"),"duration":d.get("duration"),"source":d.get("extractor_key")}
    except Exception as e:
        raise HTTPException(400,f"Не удалось получить информацию: {str(e)[:300]}")

@app.post("/download")
def download(job:Job, x_api_key:str|None=None):
    auth(x_api_key)
    if not (0<=job.quality<=10): raise HTTPException(400,"quality должен быть 0..10")
    if job.type not in ("video","audio"): raise HTTPException(400,"type должен быть video или audio")
    jid=uuid.uuid4().hex
    out=BASE/jid
    out.mkdir()
    try:
        if job.type=="audio":
            opts={
                "quiet":True,"noplaylist":True,
                "format":"ba/b",
                "outtmpl":str(out/"%(title)s.%(ext)s"),
                "postprocessors":[{"key":"FFmpegExtractAudio","preferredcodec":"mp3","preferredquality":"320"}],
            }
        else:
            opts={
                "quiet":True,"noplaylist":True,
                "format":quality_fmt(job.quality),
                "merge_output_format":"mp4",
                "outtmpl":str(out/"%(title)s.%(ext)s"),
            }
        with yt_dlp.YoutubeDL(opts) as y:
            d=y.extract_info(job.url,download=True)
        files=[p for p in out.iterdir() if p.is_file()]
        if not files: raise RuntimeError("Файл не создан")
        f=files[0]
        size=f.stat().st_size
        if size>MAX_GB*1024**3:
            raise RuntimeError("Файл превышает установленный лимит backend")
        return {"url":f"/files/{jid}/{f.name}","title":d.get("title") or f.name,"size":size}
    except Exception as e:
        shutil.rmtree(out,ignore_errors=True)
        raise HTTPException(400,f"Ошибка загрузки: {str(e)[:500]}")

@app.get("/files/{jobid}/{filename:path}")
def file(jobid:str,filename:str):
    p=(BASE/jobid/filename).resolve()
    base=(BASE/jobid).resolve()
    if base not in p.parents or not p.is_file(): raise HTTPException(404)
    return FileResponse(p,filename=p.name)

@app.on_event("startup")
async def cleanup_task():
    async def loop():
        while True:
            await asyncio.sleep(3600)
            # удаляем результаты старше 6 часов
            import time
            now=time.time()
            for d in BASE.iterdir():
                try:
                    if d.is_dir() and now-d.stat().st_mtime>21600: shutil.rmtree(d,ignore_errors=True)
                except: pass
    asyncio.create_task(loop())
