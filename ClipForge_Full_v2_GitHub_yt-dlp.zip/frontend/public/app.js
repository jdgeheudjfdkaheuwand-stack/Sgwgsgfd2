const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
let selectedType="video", current=null;
const API="/api";

function platform(u){try{let h=new URL(u).hostname.replace("www.","");if(h.includes("youtube"))return"YouTube";if(h.includes("tiktok"))return"TikTok";if(h.includes("instagram"))return"Instagram";return h}catch{return"Ссылка"}}
function loadHistory(){return JSON.parse(localStorage.getItem("cf_history")||"[]")}
function saveHistory(x){let h=loadHistory();h.unshift(x);localStorage.setItem("cf_history",JSON.stringify(h.slice(0,30)));renderHistory()}
function renderHistory(){let h=loadHistory(), box=$("#historyList");if(!h.length){box.innerHTML='<div class="empty">Здесь появятся последние загрузки.</div>';return}
box.innerHTML=h.map((x,i)=>`<div class="history-item"><div class="meta"><strong>${esc(x.title)}</strong><small>${esc(x.source)} • ${x.type==="audio"?"MP3":"MP4"} • ${x.quality}/10</small></div><button data-redownload="${i}">Повторить</button></div>`).join("")}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}

$("#quality").oninput=e=>$("#qualityText").textContent=e.target.value+"/10";
$$(".seg button").forEach(b=>b.onclick=()=>{$$(".seg button").forEach(x=>x.classList.remove("active"));b.classList.add("active");selectedType=b.dataset.type});

$("#analyze").onclick=async()=>{
 const url=$("#url").value.trim(); if(!url)return alert("Вставь ссылку.");
 try{new URL(url)}catch{return alert("Похоже, ссылка введена неверно.")}
 current={url,source:platform(url),quality:+$("#quality").value,type:selectedType,title:"Загрузка медиа"};
 $("#title").textContent="Готово к скачиванию";$("#source").textContent=current.source;
 $("#details").classList.remove("hidden");
 try{let r=await fetch(API+"/info?url="+encodeURIComponent(url));if(r.ok){let d=await r.json();current.title=d.title||current.title;$("#title").textContent=current.title;if(d.thumbnail)$("#thumb").style.background=`url("${d.thumbnail}") center/cover`;}}catch{}
};

$("#download").onclick=async()=>{
 if(!current)return;
 const box=$("#progressBox"),bar=$("#bar"),pct=$("#progressPct"),status=$("#progressStatus");box.classList.remove("hidden");
 let p=0;status.textContent="Подготовка…";
 const timer=setInterval(()=>{p=Math.min(94,p+Math.floor(Math.random()*8)+2);bar.style.width=p+"%";pct.textContent=p+"%";status.textContent=p<35?"Получаем медиа…":p<75?"Обработка…":"Подготавливаем файл…";if(p>=94)clearInterval(timer)},350);
 try{
   const r=await fetch(API+"/download",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(current)});
   if(!r.ok)throw new Error("backend");
   const d=await r.json();
   clearInterval(timer);bar.style.width="100%";pct.textContent="100%";status.textContent="Готово";
   if(d.url){let a=document.createElement("a");a.href=d.url;a.download="";a.target="_blank";a.click()}
   saveHistory(current);
 }catch(e){
   clearInterval(timer);bar.style.width="100%";pct.textContent="!";status.textContent="Скачивание не подключено";
   alert("Интерфейс готов, но загрузочный сервер ещё не подключён. Укажи DOWNLOADER_API в Worker.");
 }
};
$("#clear").onclick=()=>{localStorage.removeItem("cf_history");renderHistory()};
$("#theme").onclick=()=>document.body.classList.toggle("light");
$("#historyList").onclick=e=>{let i=e.target.dataset.redownload;if(i!==undefined){let x=loadHistory()[i];$("#url").value=x.url;$("#analyze").click();scrollTo({top:0,behavior:"smooth"})}};
renderHistory();
