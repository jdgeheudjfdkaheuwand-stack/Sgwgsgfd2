export default {
  async fetch(request, env) {
    const u=new URL(request.url);
    if (u.pathname==="/api/info" && request.method==="GET") {
      if(!env.DOWNLOADER_API) return Response.json({title:"Медиа"});
      const q=u.searchParams.get("url");
      const r=await fetch(env.DOWNLOADER_API+"/info?url="+encodeURIComponent(q),{
        headers: env.DOWNLOADER_API_KEY?{"X-API-Key":env.DOWNLOADER_API_KEY}:{}
      });
      return new Response(r.body,{status:r.status,headers:{"content-type":"application/json"}});
    }
    if (u.pathname==="/api/download" && request.method==="POST") {
      if(!env.DOWNLOADER_API) return Response.json({error:"DOWNLOADER_API is not configured"},{status:503});
      const r=await fetch(env.DOWNLOADER_API+"/download",{
        method:"POST",body:request.body,
        headers:{
          "content-type":request.headers.get("content-type")||"application/json",
          ...(env.DOWNLOADER_API_KEY?{"X-API-Key":env.DOWNLOADER_API_KEY}:{})
        }
      });
      return new Response(r.body,{status:r.status,headers:{"content-type":"application/json"}});
    }
    if(u.pathname.startsWith("/files/") && env.DOWNLOADER_API){
      return fetch(env.DOWNLOADER_API+u.pathname);
    }
    return env.ASSETS.fetch(request);
  }
};
