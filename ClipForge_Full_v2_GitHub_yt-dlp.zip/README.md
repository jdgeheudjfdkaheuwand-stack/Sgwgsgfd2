# ClipForge v2.0 — Full stack

В комплекте:
- `frontend/` — Cloudflare Worker + сайт;
- `backend/` — FastAPI + yt-dlp + FFmpeg.

Источник downloader: официальный проект yt-dlp на GitHub.
https://github.com/yt-dlp/yt-dlp

## Backend

Нужен сервер с Docker/ Python 3.12+.

```bash
cd backend
docker build -t clipforge-backend .
docker run -p 8080:8080 -e DOWNLOADER_API_KEY=CHANGE_ME clipforge-backend
```

Backend endpoints:
- `GET /health`
- `GET /info?url=...`
- `POST /download`
- `GET /files/{jobid}/{filename}`

## Cloudflare

В Worker задайте secrets/vars:
- `DOWNLOADER_API` = публичный HTTPS URL backend, например `https://downloader.example.com`
- `DOWNLOADER_API_KEY` = тот же секрет, что в backend

Деплой:
```bash
cd frontend
npm install -D wrangler
npx wrangler login
npx wrangler deploy
```

Cloudflare Workers Static Assets поддерживает размещение статических файлов вместе с Worker/API.
